// This is the CPP file you will edit and turn in.
// Also remove these comments here and add your own.
// TODO: remove this comment header!

#include <fstream>
#include <iostream>
#include <string>
#include "console.h"
#include "filelib.h"
#include "grid.h"
#include "gwindow.h"
#include "simpio.h"
#include "lifegui.h"
// Feel free to add any other #includes you might need here

using namespace std;

int main() {
    // TODO: Finish the program!
    return 0;
}
