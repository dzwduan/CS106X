/*
 * File: WelcomeToCpp.cpp
 * --------------------------
 * Name: [TODO: enter name here]
 * Section: [TODO: enter section leader here]
 * This file is the starter project for the first assignment of CS106B.
 * [TODO: rewrite the documentation]
 *
 * The repeating call sequence is
 *    triggerStackOverflow(137), which calls
 *    [TODO: fill this in], which calls
 *    triggerStackOverflow(137) again.
 */

// Please feel free to add any other #includes you need!
#include "WelcomeToCpp.h"
#include <iostream>
#include <string>

using namespace std;


void flipHeads() {
    // [TODO: fill in the code]
}


int nChooseK(int n, int k) {
    // [TODO: fill in the code]
    return 0;
}


int stringToInt(string str) {
    // [TODO: fill in the code]
    return 0;
}


string intToString(int n) {
    // [TODO: fill in the code]
    return "";
}


DocumentInfo statisticsFor(istream& source) {
    DocumentInfo docInfo;
    // [TODO: fill in the code]
    return docInfo;
}

